//**************************************************************************
// 
// Primitivas básicas para construir elementos sencillos 
// Domingo Martin Perandres 2005-2012
// Pedro Cano Olivares 2012-2013
// Dar�o L�pez Mu�oz (Modificaci�n y ampliaci�n) 
//          - Incluido control de animación
//
// License: GPL
//**************************************************************************

#include "objetos.h"
#include "estructuras.h"
#include "math.h"

#define amarillo 0
#define gris 1
#define rojo 2
#define	marron 3
#define celeste 4
#define marron2 5
#define verde 6
#define azul 7

/** Definicion de los colores usados.**/
float color[8][4]={{1,.8,.3,1.},{0.7,0.7,0.7,1},{1.0,0.0,0.0,1},
   		   {0.7,0.6,0.2,1},{0.2,1.0,1.0,1},{1.0,0.86,0.3,1},
		   {0.0,1.0,0.0,1.0}, {0.0,0.0,1.0,1.0}};


//*************************************************************************
// _object3D
//*************************************************************************
//*************************************************************************
//
//*************************************************************************

_object3D::_object3D()
{


Point_size=POINT_SIZE;
Line_width=LINE_WIDTH;
}

//*************************************************************************
//
//*************************************************************************

void _object3D::draw()
{

}


//*************************************************************************
// Robot
//*************************************************************************
//*************************************************************************
//
//*************************************************************************

robot::robot()
{
	rdefault();
}

//*************************************************************************
//
//*************************************************************************

void robot::draw()
{
GLfloat Light_position[4]={5.0, 5.0, 10.0, 0.0};
GLfloat Ambient_component[4]={0.4,0.4,0.4,1};

glEnable(GL_CULL_FACE);
glLightModelfv(GL_LIGHT_MODEL_AMBIENT,Ambient_component);
glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,GL_TRUE);

glMatrixMode(GL_MODELVIEW);
glPushMatrix();
glLoadIdentity();
glLightfv(GL_LIGHT0,GL_POSITION,Light_position);
glPopMatrix();
glShadeModel(GL_FLAT);
glEnable(GL_LIGHTING);
glEnable(GL_LIGHT0);
glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

glPushMatrix(); 
	glScalef(2,2,2);
	
	/* 				BLOQUE CABEZA = CABEZA + OJOS + OJOSL 				*/
    
glPushMatrix();
glRotatef(giro_cabeza,0,1,0);
	
	//Cabeza
	glPushMatrix();
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[rojo]);
	glTranslatef(0,5+rcuello,0);
	caja(1.5,1.5,1.5);
	glPopMatrix();
	

	// Ojos
	glPushMatrix();
	glTranslatef(-0.3,6+rcuello,0.8);
	glScalef(2,2,1.5);
	glRotatef(-90,1,0,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[amarillo]);
	conof(0,0,0,0,.25,0,.1,10);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.3,6+rcuello,0.8);
	glScalef(2,2,1.5);
	glRotatef(-90,1,0,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[amarillo]);
	conof(0,0,0,0,.25,0,.1,10);
	glPopMatrix();

	//Ojos laser
	glPushMatrix();
	glTranslatef(-0.3,6+rcuello,0.8);
	glRotatef(180,1,0,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[rojo]);
	glutWireCone(0.1,1*d_laser,50,20);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.3,6+rcuello,0.8);
	glRotatef(180,1,0,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[rojo]);
	glutWireCone(0.1,1*d_laser,50,20);
	glPopMatrix();
	
glPopMatrix();

/* -------------------------------------------------------------------- */
	
	//Cuello
	glPushMatrix();
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[gris]);
	glTranslatef(0,5,0);
	caja(1,rcuello,1);
	glPopMatrix();

	// Cuerpo
	glPushMatrix();
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[gris]);
	caja(3,5,2);
	glPopMatrix();
	
	//Pierna derecha (Top)
	glPushMatrix();
	glTranslatef(1,-3,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[rojo]);
	caja(1,3,1);
	glPopMatrix();

	//Pierna derecha (Bot)
	glPushMatrix();
	glTranslatef(1,-3.5,0.4);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[amarillo]);
	caja(1.2,0.5,2.2);
	glPopMatrix();

	//Pierna izquierda (Top)
	glPushMatrix();
	glTranslatef(-1,-3,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[rojo]);
	caja(1,3,1);
	glPopMatrix();

	//Pierna izquierda (Bot)
	glPushMatrix();
	glTranslatef(-1,-3.5,0.4);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[amarillo]);
	caja(1.2,0.5,2.2);
	glPopMatrix();

/* 								BLOQUE BRAZOS                                   */
	// Brazo derecho (Hombro)
	glPushMatrix();
	glTranslatef(2,4.5,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[marron2]);
	caja(1,0.5,0.5);
	glPopMatrix();


	// Brazo izquierdo (Hombro)
	glPushMatrix();
	glTranslatef(-2,4.5,0);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[marron2]);
	caja(1,0.5,0.5);
	glPopMatrix();

  /* 				PARTE DEL BRAZO QUE VA A SER ROTAR  				*/
	
	// Brazo derecho (Antebrazo)
	glPushMatrix();
	glTranslatef(2.5,4,0);
	glRotatef(-90,0,0,1);
	/* 				TRANSLACIÓN NECESARIA PARA EL CORRECTO GIRO			 */
	glTranslatef(-0.5,0,0);
	glRotatef(giro_brazod,0,-1,0);
	glTranslatef(0.5,0,0);
	/* -----------------------------------------------*/
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[marron]);
	caja(2,1,1);
	glPopMatrix();
	
	// Brazo izquierdo (Antebrazo)
	glPushMatrix();
	glTranslatef(-2.5,4,0);
	glRotatef(90,0,0,1);
	/* 				TRANSLACIÓN NECESARIA PARA EL CORRECTO GIRO			 */
	glTranslatef(0.5,0,0);
	glRotatef(giro_brazoi,0,1,0);
	glTranslatef(-0.5,0,0);
	/* -----------------------------------------------*/
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[marron]);
	caja(2,1,1);
	glPopMatrix();

	// Brazo derecho (Mano)
	glPushMatrix();
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[amarillo]);
	glTranslatef(3,2.6,0);
	glTranslatef(0,1.9,0);
	glRotatef(-giro_brazod,1,0,0);
	glRotatef(giro_manos,0,1,0);
	glTranslatef(0,-1.9,0);
	caja(0.5,0.5,rmanod);
	glPopMatrix();
	
	// Brazo izquierdo (Mano)
	glPushMatrix();
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[amarillo]);
	glTranslatef(-3,2.6,0);
	glTranslatef(0,1.9,0);
	glRotatef(-giro_brazoi,1,0,0);
	glRotatef(giro_manos,0,1,0);
	glTranslatef(0,-1.9,0);
	caja(0.5,0.5,rmanoi);
	glPopMatrix();
	
   /* -------------------------------------------------------------------- */

glPopMatrix();
}

//*************************************************************************

void robot::cabeza_right()
{
	giro_cabeza-=1;
}

//*************************************************************************

void robot::cabeza_left()
{
	giro_cabeza+=1;
}

//*************************************************************************

void robot::brazos_arriba()
{
	giro_brazod+=2;
	giro_brazoi+=2;
}

//*************************************************************************

void robot::brazos_abajo()
{
	giro_brazod-=2;
	giro_brazoi-=2;
}

//*************************************************************************

void robot::brazod_abajo()
{
	giro_brazod-=2;
}

//*************************************************************************

void robot::brazod_arriba()
{
	giro_brazod+=2;
}

//*************************************************************************

void robot::brazoi_abajo()
{
	giro_brazoi-=2;
}

//*************************************************************************

void robot::brazoi_arriba()
{
	giro_brazoi+=2;
}

//*************************************************************************

void robot::cuello_aumentar()
{
	rcuello+=0.5;
}

//*************************************************************************

void robot::manoi_aumentar()
{
	rmanoi+=0.5;
}

//*************************************************************************

void robot::manoi_disminuir()
{
	rmanoi-=0.5;
}

//*************************************************************************

void robot::manod_aumentar()
{
	rmanod+=0.5;
}

//*************************************************************************

void robot::manod_disminuir()
{
	rmanod-=0.5;
}

//*************************************************************************

void robot::cuello_disminuir()
{
	rcuello-=0.5;
}

//*************************************************************************

void robot::rdefault()
{
	giro_cabeza=0;
	giro_brazod=0;
	giro_brazoi=0;
	rcuello=0.5; 
	rmanod=0.5;
	rmanoi=0.5;
}

//*************************************************************************

void robot::girar_manos()
{
	giro_manos-=30;
}

//*************************************************************************

void robot::act_giro_manos()
{	
	act_g_manos=true;	
}

//*************************************************************************

bool robot::getgmanos()
{	
	return act_g_manos;	
}

//*************************************************************************
void robot::laser()
{	
	d_laser=d_laser-5;	
}

//*************************************************************************

void robot::act_laser()
{	
	 act_laserv=true;	
	
}

//*************************************************************************

bool robot::getlaser()
{	
	return act_laserv;	
	
}

//*************************************************************************
void robot::control_animacion()
{
    if(giro_cabeza>45) giro_cabeza =45;
    if(giro_cabeza<-45) giro_cabeza = -45;
    if(rcuello<0.5) rcuello = 0.5;
    if(rcuello>5) rcuello = 5;
    if(rmanoi<0.5) rmanoi = 0.5;
    if(rmanoi>3) rmanoi = 3;
    if(rmanod<0.5) rmanod = 0.5;
    if(rmanod>3) rmanod = 3;
    if(giro_manos<-50000) {giro_manos=0; act_g_manos=false; }
    if(d_laser<-30){ d_laser=0; act_laserv=false;}
}

