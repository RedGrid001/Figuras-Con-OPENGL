//**************************************************************************
//Dar�o L�pez Mu�oz - GPL
//**************************************************************************

#ifndef _OBJETOS
#define _OBJETOS


#include <stdlib.h>
#include <GL/glut.h>

using namespace std;


const float POINT_SIZE=3;
const float LINE_WIDTH=1;

//*************************************************************************
//
//*************************************************************************

class _object3D
{
public:

			_object3D();
void 	draw();

float Point_size;
float Line_width;
};


//*************************************************************************
// ROBOT
//*************************************************************************

class robot: public _object3D
{
public:

		robot();
    void draw();

	void cabeza_right();
	void cabeza_left();
	void laser();
	void brazos_arriba();
	void brazos_abajo();
	void brazod_abajo();
	void brazod_arriba();
	void brazoi_abajo();
	void brazoi_arriba();
	void cuello_aumentar();
	void cuello_disminuir();
	void manod_aumentar();
	void manod_disminuir();
	void manoi_aumentar();
	void manoi_disminuir();
	void girar_manos();
	bool getgmanos();
	void act_giro_manos();
	void rdefault();
	void act_laser();
	bool getlaser();
    	void control_animacion();
	
    // Parámetros de construcción
	float giro_cabeza;
	float giro_brazod, giro_brazoi;
	float rcuello,rmanod,rmanoi;
	float giro_manos;
	float d_laser; //Distancia de laser
	bool act_laserv; //Control de laser
	bool act_g_manos; // Control del giro de manos

};


	
#endif


